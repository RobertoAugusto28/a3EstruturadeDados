import json
import random

def gerar_dados_teste(numero_entregas, numero_centros):
    dados = {
        "centros": [f"Centro{i}" for i in range(numero_centros)],
        "distancias": [
            {"origem": f"Centro{i}", "destino": f"Destino{j}", "distancia": random.randint(1, 100)}

            for i in range(numero_centros) for j in range(10)
        ],
        "entregas": [
            {"destino": f"Destino{random.randint(0, 9)}", "peso": random.randint(1, 100), "prazo": "2024-12-31"}

            for _ in range(numero_entregas)
        ]
    }
    with open("data_set.json", "w", encoding="utf-8") as file:
        json.dump(dados, file)

gerar_dados_teste(500000, 10)
