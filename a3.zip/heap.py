import json
import heapq
import networkx as nx
from datetime import datetime
import time

class Entrega:
    def __init__(self, destino, peso, prazo):
        self.destino = destino
        self.peso = peso
        self.prazo = datetime.strptime(prazo, "%Y-%m-%d")

class Caminhao:
    def __init__(self, capacidade, limite_horas):
        self.capacidade = capacidade
        self.limite_horas = limite_horas
        self.carga_atual = 0
        self.entregas = []

    def pode_carregar(self, peso):
        return self.carga_atual + peso <= self.capacidade

    def espaco_disponivel(self):
        return self.capacidade - self.carga_atual

    def alocar_entrega(self, entrega):
        if self.pode_carregar(entrega.peso):
            self.carga_atual += entrega.peso
            self.entregas.append(entrega)
            return True
        return False

    def __lt__(self, other):
        # Usando a capacidade disponível como critério para a comparação no heap
        return self.espaco_disponivel() > other.espaco_disponivel()

class CentroDeDistribuicao:
    def __init__(self, nome):
        self.nome = nome
        self.entregas = []

def carregar_dados_json(caminho_arquivo):
    with open(caminho_arquivo, "r", encoding="utf-8") as file:
        return json.load(file)

def criar_grafo(dados):
    grafo = nx.Graph()
    for aresta in dados["distancias"]:
        grafo.add_edge(aresta["origem"], aresta["destino"], weight=aresta["distancia"])
    return grafo

def criar_entregas(dados):
    return [Entrega(entrega["destino"], entrega["peso"], entrega["prazo"]) for entrega in dados["entregas"]]

def alocar_entregas(grafo, centros, entregas):
    for entrega in entregas:
        centro_proximo = min(
            centros,
            key=lambda centro: nx.shortest_path_length(grafo, centro.nome, entrega.destino, weight="weight")
        )

        centro_proximo.entregas.append(entrega)

# Planejar rotas usando heap para gerenciamento de caminhões
def planejar_rotas(centro, capacidade=1000, limite_horas=8):
    caminhões_heap = []

    # Criação do primeiro caminhão e adicionando no heap
    heapq.heappush(caminhões_heap, Caminhao(capacidade, limite_horas))

    for entrega in centro.entregas:
        # Tentativa de alocar a entrega no caminhão com maior espaço disponível

        caminhao = heapq.heappop(caminhões_heap)

        if caminhao.alocar_entrega(entrega):
            # Se a entrega for alocada com sucesso, adiciona o caminhão de volta ao heap
            heapq.heappush(caminhões_heap, caminhao)
        else:
            # Se não for possível alocar no caminhão atual, cria um novo caminhão
            novo_caminhao = Caminhao(capacidade, limite_horas)
            novo_caminhao.alocar_entrega(entrega)

            # Adiciona o novo caminhão ao heap
            heapq.heappush(caminhões_heap, novo_caminhao)

    return caminhões_heap

# Simular entregas
def simular_entregas(caminho_arquivo):
    dados = carregar_dados_json(caminho_arquivo)
    grafo = criar_grafo(dados)
    centros = [CentroDeDistribuicao(nome) for nome in dados["centros"]]
    entregas = criar_entregas(dados)

    alocar_entregas(grafo, centros, entregas)

    resultados = {centro.nome: planejar_rotas(centro) for centro in centros}

    return resultados

def exibir_resultados(resultados):
    for centro, rotas in resultados.items():
        print(f"Centro de Distribuição: {centro}")
        for i, caminhao in enumerate(rotas):
            print(f"  Caminhão {i + 1}:")
            for entrega in caminhao.entregas:
                print(f"    - Destino: {entrega.destino}, Peso: {entrega.peso} kg")
        print()

if __name__ == "__main__":
    inicio = time.time()

    resultados = simular_entregas("data_set.json")

    fim = time.time()
    duracao = fim - inicio

    print(f"Tempo total de execução: {duracao:.3f} segundos")
